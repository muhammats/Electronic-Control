/*********************************************************************************************************
*
* File                : HzLib.h
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : sasa_xiao
*
*                                  (c) Copyright 2005-2011, WaveShare
*                                       http://www.waveshare.net
*                                          All Rights Reserved
*
*********************************************************************************************************/


#ifndef __HZLIB_H
#define __HZLIB_H 

/* Includes ------------------------------------------------------------------*/
#include <string.h>

/* Private function prototypes -----------------------------------------------*/
void GetGBKCode(unsigned char* pBuffer,unsigned char * c);

#endif 


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/





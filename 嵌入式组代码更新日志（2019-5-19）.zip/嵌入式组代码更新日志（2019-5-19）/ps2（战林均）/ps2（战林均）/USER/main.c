#include "delay.h"
#include "sys.h"
#include "ps2.h"
#include "usart2.h"
#include "timer.h"
#define MAX 20
#define PAS 17





u8 cum_num[10],ang[5]={90,90,90,90,90};			//cum_num��0-3�ֱ����������������,4-7���ҷ������������




void NumClear(void);


 int main(void)
 {		    
	u8 PS2_KEY = 0; 
	u16 num = 0;
	u16 debounce=0;

	 
	delay_init();	    				 //��ʱ������ʼ��	  	 
    Uart2_Init(9600);	                //usart��ʼ��
	delay_ms(10);
    USART_SendData(USART2,'1');  		 //���ڲ��ԣ�1
	TIM2_3_PWM_Init(2000-1, 720-1);
	PrintChar("\t hello \r\n");
    PS2_Init();
	PrintChar("\t PS2 \r\n");
	 
	 
	PS2_TurnOnAnalogMode();
   	while(1)
	{
		
		if(debounce == MAX)
		{
			debounce = 0;
			
			
			
//��֪������ʲô���� ����д��ҵ ���������ñ��취�Ѵ���ʵ�� �����������ִ�����if�ж�.............
			//1�Ŷ��
			if(cum_num[0]>=PAS)
			{	
				printf("num.%d",0);
				if((ang[0]<=180)) ang[0]+=3;
				
				Rds_Control(ang[0],1);
			}
			
			if(cum_num[1]>=PAS)
			{	
				printf("num.%d",1);
				if((ang[0]>=3)) ang[0]-=3;
				
				Rds_Control(ang[0],1);
			}
			//2�Ŷ��
			if(cum_num[2]>=PAS)
			{	
				printf("num.%d",2);
				if((ang[1]<=180)) ang[1]+=3;
				
				Rds_Control(ang[1],2);
			}
			
			if(cum_num[3]>=PAS)
			{	
				printf("num.%d",3);
				if((ang[1]>=3)) ang[1]-=3;
				
				Rds_Control(ang[1],2);
			}
			
			//3�Ŷ��
			if(cum_num[4]>=PAS)
			{	
				printf("num.%d",4);
				if((ang[2]<=180)) ang[2]+=3;
				
				Rds_Control(ang[2],3);
			}
			
			if(cum_num[5]>=PAS)
			{	
				printf("num.%d",5);
				if((ang[2]>=3)) ang[2]-=3;
				
				Rds_Control(ang[2],3);
			}
			//4�Ŷ��
			if(cum_num[6]>=PAS)
			{	
				printf("num.%d",6);
				if((ang[3]<=180)) ang[3]+=3;
				
				Rds_Control(ang[3],4);
			}
			
			if(cum_num[7]>=PAS)
			{	
				printf("num.%d",7);
				if((ang[3]>=3)) ang[3]-=3;
				
				Rds_Control(ang[3],4);
			}
			//5�Ŷ��
			if(cum_num[8]>=PAS)
			{	
				printf("num.%d",8);
				if((ang[4]<=180)) ang[4]+=3;
				
				Rds_Control(ang[4],5);
			}
			
			if(cum_num[9]>=PAS)
			{	
				printf("num.%d",9);
				if((ang[4]>=3)) ang[4]-=3;
				
				Rds_Control(ang[4],5);
			}
//ok �͵������� ��ע�ͷָ��� �ȽϺÿ�
			
			
			NumClear();
		}
		
		num++;
		if(num == 50000)
		{
			debounce++;
			num = 0;
			PS2_KEY = PS2_DataKey();	 //�ֱ�����������
			switch(PS2_KEY)
			{
				case PSB_SELECT: 	cum_num[8]++; break;
				case PSB_L3:     	PrintChar("PSB_L3 \n");  break;  
				case PSB_R3:     	PrintChar("PSB_R3 \n");  break;  
				case PSB_START:  	cum_num[9]++; break;  
				case PSB_PAD_UP: 	cum_num[0]++; break;  
				case PSB_PAD_RIGHT:	cum_num[3]++; break;
				case PSB_PAD_DOWN:	cum_num[1]++; break; 
				case PSB_PAD_LEFT:	cum_num[2]++; break; 
				case PSB_L2:      	PrintChar("PSB_L2 \n");  break; 
				case PSB_R2:      	PrintChar("PSB_R2 \n");  break; 
				case PSB_L1:      	PrintChar("PSB_L1 \n");  break; 
				case PSB_R1:      	PrintChar("PSB_R1 \n");  break;     
				case PSB_TRIANGLE:	cum_num[4]++; break; 
				case PSB_CIRCLE:  	cum_num[7]++; break; 
				case PSB_CROSS:   	cum_num[5]++; break; 
				case PSB_SQUARE:  	cum_num[6]++; break;
				default:  break; 
			}
			
		

	}
	 }
 }
 
void NumClear(void)
{
	u8 i=0;
	for(i=0;i<=9;i++)
	{
		cum_num[i] = 0;
	}
}

 



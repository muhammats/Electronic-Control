#include "timer.h"
#include "sys.h"
#include "delay.h"
#include "usart2.h"	
//TIMER3���жϷ������
//void TIM3_IRQHandler(void)
//{
//	if(TIM3->SR&0x0001) LED1 = !LED1;		//���
//	TIM3->SR&=~(1<<0);
//}

void TIM2_3_PWM_Init(u16 arr, u16 psc)
{
	RCC->APB2ENR |= ((1<<2)+(1<<3));		//GPIOA Bʹ��
	RCC->APB1ENR |= ((1<<0)+(1<<2));		//TIM2 4ʱ��ʹ��
	GPIOA->CRL&=0xFFFFFF00;
	GPIOA->CRL|=0x000000bb;
	GPIOB->CRL&=0x00FFFFFF;
	GPIOB->CRL|=0xbb000000;
	GPIOB->CRH&=0xFFFFFFF0;
	GPIOB->CRH|=0x0000000b;

	TIM2->ARR = arr;TIM4->ARR = arr;			//Ԥ����װֵ
	TIM2->PSC = psc;TIM4->PSC = psc;			//Ԥ��Ƶ��720 ���100khz�ļ���ʱ��

	TIM2->CR1=0x0080;TIM4->CR1=0x0080;			   	//ARPEʹ��
	TIM2->CR1 |= 0X01;TIM4->CR1 |= 0X01;			//ʹ�ܶ�ʱ��
	
	TIM2->CCMR1|=7<<4;				//��·pwm������pwm2ģʽ
	TIM2->CCMR1|=7<<12;  	
	TIM4->CCMR1|=7<<4;
	TIM4->CCMR1|=7<<12;
	TIM4->CCMR2|=7<<4;
	
	TIM2->CCMR1|=1<<3;				//Ԥװ��ʹ��	
	TIM2->CCMR1|=1<<11; 
	TIM4->CCMR1|=1<<3;
	TIM4->CCMR1|=1<<11;	
	TIM4->CCMR2|=1<<3;
	
 	TIM4->CCER|=((1<<0) + (1<<4) + (1<<8));   	//OC���ʹ��	   
	TIM2->CCER|=((1<<0) + (1<<4));
	CH1_PWM_VAL = 240;
	CH2_PWM_VAL = 240;
	CH3_PWM_VAL = 240;
	CH4_PWM_VAL = 240;
	CH5_PWM_VAL = 240;
	
//	TIM3->DIER |= 1<<0;			//���������ж�
//	MY_NVIC_Init(1,3,TIM3_IRQn,2);	//��ռ1 ��Ӧ2 ��2
}


void Rds_Control(u8 ang,u8 serial_num)
{
	switch(serial_num)					//pwm_val��150-330֮��
	{
		case 1:	CH1_PWM_VAL = (150 + ang);break;
		case 2:	CH2_PWM_VAL = (150 + ang);break;
		case 3:	CH3_PWM_VAL = (150 + ang);break;
		case 4:	CH4_PWM_VAL = (150 + ang);break;
		case 5:	CH5_PWM_VAL = (150 + ang);break;
		default:printf("wrong steering number");
	}
}

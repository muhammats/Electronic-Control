
#ifndef __USART2_H
#define __USART2_H

#include "sys.h"
#include "stdio.h"

void Uart2_Init(u32 baud);
void USART2_Send_Byte(unsigned char byte);
void PrintChar(char *s);

#endif

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "sensor_msgs/JointState.h"
#include "serial/serial.h"
/** * This tutorial demonstrates simple receipt of messages over the ROS system. */
serial::Serial ros_ser; 
void jointstatesCallback(const sensor_msgs::JointStateConstPtr& msg)
{
    uint8_t buffer[1024];	
    int i;	
    size_t pos[6],vel[6]; // pos=msg.position;  
    pos[0]=msg->position[0];
    pos[1]=msg->position[1];
    pos[2]=msg->position[2];
    pos[3]=msg->position[3];
    pos[4]=msg->position[4];
    pos[5]=msg->position[5];
    vel[0]=msg->velocity[0];
    vel[1]=msg->velocity[1];
    vel[2]=msg->velocity[2];
    vel[3]=msg->velocity[3];
    vel[4]=msg->velocity[4];
    vel[5]=msg->velocity[5];  
   
/********************************************************************/

    for(i=0;i<6;i++){ 
    ros_ser.write(buffer,msg->position[i]);
    ROS_INFO_STREAM("Write to serial port" << msg->position[i]);
    if(i==5){
        //ros_ser.write();
            }
      }
/*********************************************************************/
    } 
int main(int argc, char **argv)
{   
    ros::init(argc, argv, "listener");    
    ros::NodeHandle n;    
    ros::Subscriber sub = n.subscribe("joint_states", 1, jointstatesCallback);
    ros::Rate loop_rate(10);
    try
     {
         ros_ser.setPort("/dev/ttyUSB0");
         ros_ser.setBaudrate(115200);
         serial::Timeout to = serial::Timeout::simpleTimeout(1000);
         ros_ser.setTimeout(to);
         ros_ser.open();
     }
     catch (serial::IOException& e)
     {
         ROS_ERROR_STREAM("Unable to open port ");
         return -1;
     }

     if(ros_ser.isOpen())
     {
         ROS_INFO_STREAM("Serial Port opened");
     }
     else
     {
         return -1;
     }
    ros::spin();
    loop_rate.sleep();
    return 0;
}

#ifndef __JDQ_H

#define __JDQ_H

void relay_init(void);
void relay_on(void);

void relay_off(void);


#endif
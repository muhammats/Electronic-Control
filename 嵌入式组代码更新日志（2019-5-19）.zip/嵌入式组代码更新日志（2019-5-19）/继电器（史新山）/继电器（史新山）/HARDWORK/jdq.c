#include "stm32f4xx.h"
#include "jdq.h"
void relay_init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}


void relay_on(void)
{
  GPIO_SetBits(GPIOB,GPIO_Pin_7);
}
 void relay_off(void)
{
  GPIO_ResetBits(GPIOB,GPIO_Pin_7);
}
